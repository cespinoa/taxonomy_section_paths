<?php

namespace Drupal\taxonomy_section_paths\Form;

if (!function_exists('Drupal\taxonomy_section_paths\Form\batch_set')) {
  function batch_set(array $batch) {
    // Stub: simula batch_set sin ejecutar lógica real.
  }
}
