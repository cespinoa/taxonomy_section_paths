<?php
// tests/src/Kernel/Drush/Commands/TaxonomySectionPathsTestDataCommands/DrushStyleStub.php

namespace Drush\Style;

use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Stub de DrushStyle para tests.
 */
class DrushStyle extends SymfonyStyle {
  // Hereda todo de SymfonyStyle, incluyendo constructor.
}
